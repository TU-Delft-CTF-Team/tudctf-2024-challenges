package fun.xitter.xitterbackend.models;

public enum UserRole {
    USER,
    MODERATOR,
    ADMIN
}
