package fun.xitter.xitterbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XitterBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
