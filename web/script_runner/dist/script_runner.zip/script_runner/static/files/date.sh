#!/bin/sh
echo "The current date is: $(date)"
