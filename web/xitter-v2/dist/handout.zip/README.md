# Xitter v2

To run the challenge, use:

```bash
docker build -t xitter-v2 . && docker run -it xitter-v2
```

If you're using docker compose, run:

```bash
sudo docker compose up --build
```
