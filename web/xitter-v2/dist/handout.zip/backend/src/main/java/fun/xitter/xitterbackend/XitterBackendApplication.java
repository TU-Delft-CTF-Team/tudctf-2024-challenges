package fun.xitter.xitterbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XitterBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(XitterBackendApplication.class, args);
    }

}
