package fun.xitter.xitterbackend.dtos;

import java.io.Serializable;

public record TokenDTO(String token) implements Serializable {
}
