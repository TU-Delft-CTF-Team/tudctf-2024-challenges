// window.remote_url = "http://localhost:8080";
window.remote_url = "";
