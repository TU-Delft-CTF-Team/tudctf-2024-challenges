# Webšop

To run the webshop, first install all dependencies:

```bash
pip install -r requirements.txt
```

Then, run the shop by running

```bash
python3 -m app
```

The webshop will be available on [http://localhost:8000](http://localhost:8000).