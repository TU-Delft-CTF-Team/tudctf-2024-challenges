# The Resume of Mr. Balls

Start the challenge with `docker compose up --build` and access `http://localhost:3000` to see the result.

You can also run the challenge outside of Docker with `yarn install` and `yarn dev`.
