# Room booking system

To run, first install dependencies:

```bash
pip install -r requirements.txt
```

Then, run the application:

```bash
python -m app
```

You'll be able to access your app at [http://localhost:8000](http://localhost:8000).

The remote application runs Python 3.12.
