from fastapi.templating import Jinja2Templates

TEMPLATES = Jinja2Templates(directory="app/templates")
